-- Run this in your Supabase SQL editor
-- Table to store each LP's weekly scorecard data

CREATE TABLE IF NOT EXISTS lp_scorecards (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  person text NOT NULL,
  week_key text NOT NULL,       -- format: YYYY-MM-DD (Monday of that week)
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(person, week_key)
);

-- Auto-update timestamp on save
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER lp_scorecards_updated_at
  BEFORE UPDATE ON lp_scorecards
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Allow anonymous reads and writes (scorecard pages use anon key)
ALTER TABLE lp_scorecards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read scorecards" ON lp_scorecards
  FOR SELECT USING (true);

CREATE POLICY "Anyone can upsert scorecards" ON lp_scorecards
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update scorecards" ON lp_scorecards
  FOR UPDATE USING (true);
