# LP Scorecard Tracker — Setup Guide

## Repo
Create a new GitHub repo: `pwang318/lp-scorecards`
Enable GitHub Pages (Settings → Pages → Deploy from main branch / root)

## Files to upload
Upload all 6 HTML files to the repo root:
- isaak.html
- gavin.html
- osgood.html
- karen.html
- said.html
- jordan.html

## Private links (share these individually)
- Isaak  → https://pwang318.github.io/lp-scorecards/isaak.html
- Gavin  → https://pwang318.github.io/lp-scorecards/gavin.html
- Osgood → https://pwang318.github.io/lp-scorecards/osgood.html
- Karen  → https://pwang318.github.io/lp-scorecards/karen.html
- Said   → https://pwang318.github.io/lp-scorecards/said.html
- Jordan → https://pwang318.github.io/lp-scorecards/jordan.html

## Supabase setup (one-time)
1. Open your Supabase project → SQL Editor
2. Run the contents of SUPABASE_SETUP.sql
3. Go to Project Settings → API → copy your anon/public key
4. In each HTML file, find this line:
       const SUPABASE_KEY = "REPLACE_WITH_ANON_KEY";
   Replace with your actual anon key (same key used in your other trackers)

## Metrics
- Isaak (LP1):  1003's /10 | Realtor calls /100 | Realtor meetings scheduled /10
- Everyone else (LP2): Referred leads /16 | 1003's /13 | Pre-approvals /6 | Contracts /3 | Rltr talk to's /10

## Features
- Each person sees only their own page / data
- Navigate back/forward by week
- Data saves to Supabase (lp_scorecards table) keyed by person + week
- Color-coded progress: green = at/over goal, gold = 60%+, gray = below
- Mobile-friendly
